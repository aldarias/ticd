// Game Variables
let score = 0;
let lives = 3;
let level = 1;
let gameRunning = false;
let animationFrameId;
let lastSpawnTime = 0;
let spawnRate = 3500; // ms between drops (Slower start)
let fallSpeed = 1;    // pixels per frame (Slower start)

// Arrays to track active IPs
let activeIPs = [];

// DOM Elements
const startScreen = document.getElementById('start-screen');
const gameOverScreen = document.getElementById('game-over-screen');
const hud = document.getElementById('hud');
const gameArea = document.getElementById('game-area');
const scoreEl = document.getElementById('score');
const livesEl = document.getElementById('lives');
const levelEl = document.getElementById('level');
const finalScoreEl = document.getElementById('final-score');

// Buttons
document.getElementById('start-btn').addEventListener('click', startGame);
document.getElementById('restart-btn').addEventListener('click', startGame);

// Utility: Random Integer
function r(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

// Logic to generate an IP address (Valid or Invalid)
function generateIPInfo() {
    const isInvalid = Math.random() > 0.5; // 50% chance to be invalid
    let ipText = '';
    
    if (!isInvalid) {
        // Generate VALID IP (e.g. 192.168.1.1)
        // Keep it simple: 4 octets between 1-255 (first) and 0-255 (rest)
        ipText = `${r(1, 255)}.${r(0, 255)}.${r(0, 255)}.${r(0, 255)}`;
    } else {
        // Generate INVALID IP
        const errorType = Math.floor(Math.random() * 5);
        if (errorType === 0) {
            // Octet > 255
            ipText = `${r(256, 999)}.${r(0, 255)}.${r(0, 255)}.${r(0, 255)}`;
        } else if (errorType === 1) {
            // 5 octets
            ipText = `${r(1, 223)}.${r(0, 255)}.${r(0, 255)}.${r(0, 255)}.${r(0, 255)}`;
        } else if (errorType === 2) {
            // 3 octets
            ipText = `${r(1, 223)}.${r(0, 255)}.${r(0, 255)}`;
        } else if (errorType === 3) {
            // Leading zeros (e.g. 192.168.01.1 is strictly invalid in formats)
            ipText = `${r(1, 223)}.${r(0, 255)}.0${r(1, 9)}.${r(0, 255)}`;
        } else {
            // Unexpected characters
            const chars = ['a', 'X', '-', '_', '$'];
            const char = chars[Math.floor(Math.random()*chars.length)];
            ipText = `${r(1, 255)}.${r(0, 255)}.${char}${r(0, 9)}.${r(0, 255)}`;
        }
    }

    return { text: ipText, valid: !isInvalid };
}

// Spawns a new IP object
function spawnIP(timestamp) {
    if (timestamp - lastSpawnTime > spawnRate) {
        lastSpawnTime = timestamp;
        
        const ipInfo = generateIPInfo();
        const el = document.createElement('div');
        el.className = 'ip-drop';
        el.innerText = ipInfo.text;
        
        // Random horizontal position (10% to 80% to keep well within screen)
        el.style.left = r(10, 80) + '%'; 
        el.style.top = '-50px';
        
        // Add click listener
        el.addEventListener('mousedown', function(e) {
            if(!gameRunning) return;
            handleIPClick(el, ipInfo);
        });

        gameArea.appendChild(el);
        
        activeIPs.push({
            element: el,
            y: -50,
            info: ipInfo,
            clicked: false
        });
    }
}

// Handle click logic
function handleIPClick(element, info) {
    // Find in tracking array
    const ipObj = activeIPs.find(obj => obj.element === element);
    if (!ipObj || ipObj.clicked) return;
    
    ipObj.clicked = true;

    if (!info.valid) {
        // CORRECT CLICK (Shot an invalid IP)
        element.classList.add('ip-destroyed');
        score += 10;
        updateHUD();
        checkLevelUp();
        
        setTimeout(() => removeIP(element), 300);
    } else {
        // INCORRECT CLICK (Shot a valid IP)
        element.classList.add('ip-wrong-click');
        loseLife();
        setTimeout(() => removeIP(element), 400);
    }
}

// Game Loop
function updateGame(timestamp) {
    if (!gameRunning) return;

    spawnIP(timestamp);

    const bottomLimit = gameArea.clientHeight;

    for (let i = activeIPs.length - 1; i >= 0; i--) {
        let ipObj = activeIPs[i];
        
        if (ipObj.clicked) continue; // Skip moving if exploding

        // Move down
        ipObj.y += fallSpeed;
        ipObj.element.style.top = ipObj.y + 'px';

        // Check if reached bottom
        if (ipObj.y > bottomLimit - 50) {
            ipObj.clicked = true; // prevent further interaction
            
            if (ipObj.info.valid) {
                // VERY GOOD! Valid IP reached the system safely
                score += 5;
                ipObj.element.classList.add('ip-saved');
                ipObj.element.innerHTML = '✔ ' + ipObj.element.innerHTML;
                updateHUD();
                checkLevelUp();
                setTimeout(() => removeIP(ipObj.element), 500);
            } else {
                // BAD! Invalid IP slipped in
                loseLife();
                ipObj.element.style.borderColor = "red";
                setTimeout(() => removeIP(ipObj.element), 100);
            }
        }
    }

    if (gameRunning) {
        animationFrameId = requestAnimationFrame(updateGame);
    }
}

// Remove element from DOM and Array
function removeIP(element) {
    if (element && element.parentNode) {
        element.parentNode.removeChild(element);
    }
    activeIPs = activeIPs.filter(obj => obj.element !== element);
}

// Life loss handler
function loseLife() {
    lives--;
    updateHUD();
    
    // Screen shake effect
    document.body.style.transform = "translateX(-10px)";
    setTimeout(() => document.body.style.transform = "translateX(10px)", 50);
    setTimeout(() => document.body.style.transform = "translateX(0)", 100);

    if (lives <= 0) {
        endGame();
    }
}

// Leveling logic
function checkLevelUp() {
    // Every 50 points, speed increases
    const newLevel = Math.floor(score / 50) + 1;
    if (newLevel > level) {
        level = newLevel;
        fallSpeed += 0.5;
        spawnRate = Math.max(500, spawnRate - 200); // Caps at 500ms
        updateHUD();
    }
}

// Update UI
function updateHUD() {
    scoreEl.innerText = score;
    livesEl.innerText = lives;
    levelEl.innerText = level;
}

// Start Game
function startGame() {
    startScreen.classList.add('hidden');
    gameOverScreen.classList.add('hidden');
    hud.classList.remove('hidden');
    
    // Reset Variables
    score = 0;
    lives = 3;
    level = 1;
    fallSpeed = 1;
    spawnRate = 3500;
    lastSpawnTime = 0;
    
    updateHUD();
    
    // Clear area
    gameArea.innerHTML = '';
    activeIPs = [];
    
    gameRunning = true;
    animationFrameId = requestAnimationFrame(updateGame);
}

// End Game
function endGame() {
    gameRunning = false;
    cancelAnimationFrame(animationFrameId);
    
    finalScoreEl.innerText = score;
    hud.classList.add('hidden');
    gameOverScreen.classList.remove('hidden');
}
